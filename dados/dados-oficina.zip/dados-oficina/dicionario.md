CO - Colisão
CF - Colisão frontal
CT - Colisão traseira
CL - Colisão lateral
CV - Colisão Transversal
CP - Capotamento
TB - Tombamento
AT - Atropelamento
AA - Atropelamento animal
CH - Choque
QM - Queda moto/bicicleta
QV - Queda veículo
QD - Queda ocupante dentro
QF - Queda ocupante fora
OU - Outros
SI - Sem informação
